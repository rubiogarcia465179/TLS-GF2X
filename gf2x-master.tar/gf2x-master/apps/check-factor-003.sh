[ "`echo 12345 u | ./factor 54321 2>/dev/null | tail -n 1`" = "12345 5 p2f" ]
