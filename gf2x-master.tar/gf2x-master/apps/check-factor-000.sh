[ "`echo 12 u | ./factor 1279 2>/dev/null | tail -n 1`" = "12 41 p3f5c0802ded" ]
